"""
extract_keypoints_parallel_turbo.py
==================================
Optimizado para A100 + 128GB RAM.
Usa carga masiva en RAM y modo asíncrono para maximizar FPS.
"""

import os
import sys
import json
import argparse
import logging
import queue
import threading
import multiprocessing
from datetime import datetime
import cv2
import numpy as np

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_FRAMES_DIR   = "/home/user/work/data/PHOENIX-2014-T-release-v3/PHOENIX-2014-T/features/fullFrame-210x260px"
DEFAULT_OUTPUT_DIR   = "/home/user/work/data/openpose_output"
DEFAULT_OPENPOSE_DIR = "/home/user/work/openpose"
DEFAULT_SPLITS       = ["train", "dev", "test"]
DEFAULT_LOG_DIR      = "./"
DEFAULT_NUM_WORKERS  = 2 

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="Parallel OpenPose extraction — N workers on same GPU."
    )
    parser.add_argument("--frames_dir",   default=DEFAULT_FRAMES_DIR)
    parser.add_argument("--output_dir",   default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--openpose_dir", default=DEFAULT_OPENPOSE_DIR)
    parser.add_argument("--splits",       nargs="+", default=DEFAULT_SPLITS)
    parser.add_argument("--gpu_number",   type=int, default=0,
                        help="GPU device id (0 = first GPU)")
    parser.add_argument("--num_workers",  type=int, default=DEFAULT_NUM_WORKERS,
                        help="Number of parallel OpenPose processes")
    parser.add_argument("--log_dir",      default=DEFAULT_LOG_DIR)
    return parser.parse_args()

def setup_logger(log_dir: str, worker_id: int = -1) -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix    = f"_worker{worker_id}" if worker_id >= 0 else ""
    log_path  = os.path.join(log_dir, f"extraction_{timestamp}{suffix}.log")
    
    logger = logging.getLogger(f"extractor{suffix}")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    
    fmt = logging.Formatter("%(asctime)s | %(message)s", datefmt="%H:%M:%S")
    fh = logging.FileHandler(log_path, encoding="utf-8")
    ch = logging.StreamHandler()
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

# ---------------------------------------------------------------------------
# OpenPose Logic
# ---------------------------------------------------------------------------

def init_openpose(openpose_dir: str, gpu_number: int, logger):
    py_path = os.path.join(openpose_dir, "build", "python")
    if py_path not in sys.path:
        sys.path.insert(0, py_path)
    from openpose import pyopenpose as op

    # MODO ASÍNCRONO ACTIVADO
    params = {
        "model_folder": os.path.join(openpose_dir, "models"),
        "model_pose": "BODY_25",
        "hand": True,
        "face": False,
        "net_resolution": "320x176",
        "hand_net_resolution": "256x256",
        "render_pose": 0,
        "num_gpu": 1,
        "num_gpu_start": gpu_number,
        "disable_multi_thread": False,
    }
    
    wrapper = op.WrapperPython(op.ThreadManagerMode.Asynchronous)
    wrapper.configure(params)
    wrapper.start()
    logger.info(f"OpenPose TURBO inicializado (GPU:{gpu_number})")
    return wrapper, op

def process_video(wrapper, op, video_dir: str, output_dir: str, logger) -> tuple:
    video_name = os.path.basename(video_dir)
    os.makedirs(output_dir, exist_ok=True)

    all_frames = sorted([f for f in os.listdir(video_dir) if f.lower().endswith((".png", ".jpg"))])
    
    pending = []
    for f in all_frames:
        stem = os.path.splitext(f)[0]
        if not os.path.exists(os.path.join(output_dir, f"{stem}_keypoints.json")):
            pending.append(f)

    if not pending:
        return video_name, len(all_frames), 0

    # 1. CARGA MASIVA A RAM (128GB aprovechados)
    frames_data = []
    for f_name in pending:
        img = cv2.imread(os.path.join(video_dir, f_name))
        if img is not None:
            frames_data.append((f_name, img))

    # 2. ENVIAR A GPU (EMPLACE)
    for f_name, img in frames_data:
        datum = op.Datum()
        datum.cvInputData = img
        datum.name = f_name
        wrapper.emplace(op.VectorDatum([datum]))

    # 3. RECOGER DE GPU (POP)
    ok, skipped = (len(all_frames) - len(pending)), 0
    for _ in range(len(frames_data)):
        datums_out = op.VectorDatum()
        if wrapper.pop(datums_out):
            datum = datums_out[0]
            f_name = datum.name
            
            people = []
            if datum.poseKeypoints is not None and datum.poseKeypoints.size > 0:
                pose  = datum.poseKeypoints[0].flatten().tolist()
                lhand = datum.handKeypoints[0][0].flatten().tolist() if datum.handKeypoints is not None else [0.0]*63
                rhand = datum.handKeypoints[1][0].flatten().tolist() if datum.handKeypoints is not None else [0.0]*63
                people.append({
                    "pose_keypoints_2d": pose,
                    "hand_left_keypoints_2d": lhand,
                    "hand_right_keypoints_2d": rhand,
                })
            
            stem = os.path.splitext(f_name)[0]
            with open(os.path.join(output_dir, f"{stem}_keypoints.json"), "w") as f:
                json.dump({"people": people}, f)
            ok += 1
        else:
            skipped += 1

    return video_name, ok, skipped

def worker_fn(worker_id: int, video_dirs: list, output_dirs: list, openpose_dir: str, gpu_number: int, log_dir: str):
    logger = setup_logger(log_dir, worker_id)
    logger.info(f"=== Worker {worker_id} Turbo-Start — {len(video_dirs)} videos ===")

    try:
        wrapper, op = init_openpose(openpose_dir, gpu_number, logger)
    except Exception as e:
        logger.error(f"Worker {worker_id} falló al iniciar: {e}")
        return

    for i, (vdir, vout) in enumerate(zip(video_dirs, output_dirs), 1):
        try:
            name, ok, skip = process_video(wrapper, op, vdir, vout, logger)
            logger.info(f" [{i}/{len(video_dirs)}] ✓ '{name}' — {ok} frames")
        except Exception as e:
            logger.error(f" Error en video {vdir}: {e}")

    wrapper.stop()
    logger.info(f"=== Worker {worker_id} Finalizado ===")

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    multiprocessing.set_start_method("spawn", force=True)
    args = parse_args()
    log = setup_logger(args.log_dir)

    log.info("=== PHOENIX-2014-T Parallel TURBO Extraction ===")
    log.info(f"  Workers: {args.num_workers} | GPU: {args.gpu_number}")

    for split in args.splits:
        split_dir = os.path.join(args.frames_dir, split)
        split_out = os.path.join(args.output_dir, split)
        if not os.path.isdir(split_dir):
            log.warning(f"Split {split} no encontrado en {split_dir}")
            continue

        video_dirs = sorted([e.path for e in os.scandir(split_dir) if e.is_dir()])
        output_dirs = [os.path.join(split_out, os.path.basename(v)) for v in video_dirs]

        log.info(f"--- Procesando Split '{split}': {len(video_dirs)} videos ---")

        chunks_v = [video_dirs[i::args.num_workers] for i in range(args.num_workers)]
        chunks_o = [output_dirs[i::args.num_workers] for i in range(args.num_workers)]

        processes = []
        for wid in range(args.num_workers):
            p = multiprocessing.Process(
                target=worker_fn,
                args=(wid, chunks_v[wid], chunks_o[wid], args.openpose_dir, args.gpu_number, args.log_dir)
            )
            p.start()
            processes.append(p)

        for p in processes:
            p.join()

    log.info("=== PROCESO COMPLETADO EXITOSAMENTE ===")