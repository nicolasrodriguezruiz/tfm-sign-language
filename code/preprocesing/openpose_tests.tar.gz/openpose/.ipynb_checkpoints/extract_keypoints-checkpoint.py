"""
extract_keypoints.py
====================
Runs OpenPose on the PHOENIX-2014-T dataset frames and saves the extracted
keypoints as JSON files, mirroring the input directory structure.

Key design: OpenPose wrapper is initialised ONCE and reused for all videos,
avoiding the ~40s startup cost per video.

Input structure:
    {frames_dir}/{split}/{video_name}/images0001.png ...

Output structure:
    {output_dir}/{split}/{video_name}/images0001_keypoints.json ...

Usage:
    python extract_keypoints.py \
        --frames_dir   /path/to/PHOENIX-2014-T/features/fullFrame-210x260px \
        --output_dir   /path/to/openpose_output \
        --openpose_dir /home/user/work/openpose \
        --splits train dev test \
        --gpu_number 0
"""

import os
import sys
import json
import argparse
import logging
import queue
import threading
from datetime import datetime

import cv2

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_FRAMES_DIR   = "/home/user/work/data/PHOENIX-2014-T-release-v3/PHOENIX-2014-T/features/fullFrame-210x260px"
DEFAULT_OUTPUT_DIR   = "/home/user/work/data/openpose_output"
DEFAULT_OPENPOSE_DIR = "/home/user/work/openpose"
DEFAULT_SPLITS       = ["train", "dev", "test"]
DEFAULT_LOG_DIR      = "./"


# ---------------------------------------------------------------------------
# Logger
# ---------------------------------------------------------------------------

def setup_logger(log_dir: str) -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path  = os.path.join(log_dir, f"extraction_{timestamp}.log")

    logger = logging.getLogger("keypoint_extractor")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    fmt = logging.Formatter("%(asctime)s | %(message)s", datefmt="%H:%M:%S")
    fh  = logging.FileHandler(log_path, encoding="utf-8")
    ch  = logging.StreamHandler()
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)

    logger.info(f"Log file: {log_path}")
    return logger


log = logging.getLogger("keypoint_extractor")


# ---------------------------------------------------------------------------
# OpenPose initialisation — called ONCE at startup
# ---------------------------------------------------------------------------

def init_openpose(openpose_dir: str, gpu_number: int = 0):
    """
    Import pyopenpose and return an initialised Wrapper.
    Called once at startup — the wrapper is reused for all videos and frames.

    gpu_number: 0 = first GPU, -1 = CPU
    """
    py_path = os.path.join(openpose_dir, "build", "python")
    if py_path not in sys.path:
        sys.path.insert(0, py_path)

    try:
        import pyopenpose as op
    except ImportError as e:
        raise ImportError(
            f"Could not import pyopenpose: {e}\n"
            f"Make sure the .so is in site-packages or in {py_path}"
        )

    params = {
        "model_folder":          os.path.join(openpose_dir, "models"),
        "model_pose":            "BODY_25",
        "hand":                  True,
        "face":                  False,
        "net_resolution":        "-1x256",
        "num_gpu":               1,
        "num_gpu_start":         gpu_number,
        "disable_multi_thread":  False,
    }

    if gpu_number < 0:
        params["render_pose"] = 0

    wrapper = op.WrapperPython()
    wrapper.configure(params)
    wrapper.start()

    mode = "CPU" if gpu_number < 0 else f"GPU:{gpu_number}"
    log.info(f"OpenPose wrapper initialised ({mode}). Will be reused for all videos.")
    return wrapper, op


# ---------------------------------------------------------------------------
# Per-video extraction — pipelined reader / inference / writer
# ---------------------------------------------------------------------------

def process_video(wrapper, op, video_dir: str, output_dir: str,
                  read_ahead: int = 32) -> tuple:
    """
    Extract keypoints using a 3-stage pipeline:

        [Reader thread]  →  read_queue  →  [OpenPose main thread]
                                        →  write_queue  →  [Writer thread]

    The reader pre-loads PNG files into RAM while OpenPose is processing
    the previous frame. The writer flushes JSON to disk in parallel.
    This overlaps I/O with GPU inference, reducing idle time.

    read_ahead: number of frames to buffer in the read queue (default 8).
    """
    _SENTINEL = None   # signals end-of-stream to downstream stages

    video_name = os.path.basename(video_dir)
    os.makedirs(output_dir, exist_ok=True)

    all_frames = sorted([
        f for f in os.listdir(video_dir)
        if f.lower().endswith(".png") or f.lower().endswith(".jpg")
    ])

    # Collect only pending frames
    pending = []
    already_done = 0
    for frame_file in all_frames:
        stem = os.path.splitext(frame_file)[0]
        if os.path.exists(os.path.join(output_dir, f"{stem}_keypoints.json")):
            already_done += 1
        else:
            pending.append(frame_file)

    if not pending:
        return video_name, already_done, 0

    read_queue  = queue.Queue(maxsize=read_ahead)
    write_queue = queue.Queue(maxsize=read_ahead)
    errors      = []

    # ------------------------------------------------------------------
    # Stage 1 — Reader: load PNGs into RAM ahead of inference
    # ------------------------------------------------------------------
    def reader():
        for frame_file in pending:
            img = cv2.imread(os.path.join(video_dir, frame_file))
            if img is None:
                errors.append(f"Could not read {frame_file}")
                read_queue.put((frame_file, None))
            else:
                read_queue.put((frame_file, img))
        read_queue.put(_SENTINEL)

    # ------------------------------------------------------------------
    # Stage 3 — Writer: serialize keypoints to JSON on a separate thread
    # ------------------------------------------------------------------
    def writer():
        while True:
            item = write_queue.get()
            if item is _SENTINEL:
                break
            frame_file, keypoints = item
            stem        = os.path.splitext(frame_file)[0]
            output_path = os.path.join(output_dir, f"{stem}_keypoints.json")
            try:
                with open(output_path, "w") as f:
                    json.dump(keypoints, f)
            except Exception as e:
                errors.append(f"Write error {frame_file}: {e}")
            finally:
                write_queue.task_done()

    reader_thread = threading.Thread(target=reader, daemon=True)
    writer_thread = threading.Thread(target=writer, daemon=True)
    reader_thread.start()
    writer_thread.start()

    # ------------------------------------------------------------------
    # Stage 2 — Inference: main thread runs OpenPose (not thread-safe)
    # ------------------------------------------------------------------
    ok, skipped = already_done, 0
    while True:
        item = read_queue.get()
        if item is _SENTINEL:
            break
        frame_file, img = item
        if img is None:
            skipped += 1
            continue
        try:
            datum = op.Datum()
            datum.cvInputData = img
            wrapper.emplaceAndPop(op.VectorDatum([datum]))

            people = []
            if datum.poseKeypoints is not None and len(datum.poseKeypoints) > 0:
                pose  = datum.poseKeypoints[0].flatten().tolist()
                lhand = datum.handKeypoints[0][0].flatten().tolist() \
                        if datum.handKeypoints is not None else [0.0] * 63
                rhand = datum.handKeypoints[1][0].flatten().tolist() \
                        if datum.handKeypoints is not None else [0.0] * 63
                people.append({
                    "pose_keypoints_2d":       pose,
                    "hand_left_keypoints_2d":  lhand,
                    "hand_right_keypoints_2d": rhand,
                })
            write_queue.put((frame_file, {"people": people}))
            ok += 1
        except Exception as e:
            log.warning(f"  [{video_name}] Inference error {frame_file}: {e}")
            skipped += 1

    # Drain writer
    write_queue.put(_SENTINEL)
    writer_thread.join()
    reader_thread.join()

    if errors:
        for err in errors:
            log.warning(f"  [{video_name}] {err}")

    return video_name, ok, skipped


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="Extract OpenPose keypoints from PHOENIX-2014-T frames."
    )
    parser.add_argument("--frames_dir",   default=DEFAULT_FRAMES_DIR,
                        help="Root dir with split sub-folders of PNG frames")
    parser.add_argument("--output_dir",   default=DEFAULT_OUTPUT_DIR,
                        help="Root dir where JSON keypoints will be saved")
    parser.add_argument("--openpose_dir", default=DEFAULT_OPENPOSE_DIR,
                        help="Root of the compiled OpenPose repo")
    parser.add_argument("--splits",       nargs="+", default=DEFAULT_SPLITS,
                        help="Which splits to process (train dev test)")
    parser.add_argument("--gpu_number",   type=int, default=0,
                        help="GPU device id (0 = first GPU, -1 = CPU)")
    parser.add_argument("--log_dir",      default=DEFAULT_LOG_DIR)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    log  = setup_logger(args.log_dir)

    log.info("=== PHOENIX-2014-T Keypoint Extraction ===")
    log.info(f"  frames_dir   : {args.frames_dir}")
    log.info(f"  output_dir   : {args.output_dir}")
    log.info(f"  openpose_dir : {args.openpose_dir}")
    log.info(f"  splits       : {args.splits}")
    log.info(f"  gpu_number   : {'CPU' if args.gpu_number < 0 else args.gpu_number}")

    # ------------------------------------------------------------------
    # Init OpenPose ONCE — shared across all splits, videos and frames
    # ------------------------------------------------------------------
    wrapper, op = init_openpose(args.openpose_dir, args.gpu_number)

    total_ok, total_skipped = 0, 0

    for split in args.splits:
        split_dir = os.path.join(args.frames_dir, split)
        split_out = os.path.join(args.output_dir, split)

        if not os.path.isdir(split_dir):
            log.warning(f"Split dir not found, skipping: {split_dir}")
            continue

        video_dirs = sorted([
            e.path for e in os.scandir(split_dir) if e.is_dir()
        ])
        log.info(f"--- Split '{split}': {len(video_dirs)} videos ---")

        for i, vdir in enumerate(video_dirs, 1):
            vout = os.path.join(split_out, os.path.basename(vdir))
            try:
                name, ok, skipped = process_video(wrapper, op, vdir, vout)
                total_ok      += ok
                total_skipped += skipped
                status = "✓" if skipped == 0 else f"⚠ {skipped} skipped"
                log.info(f"  [{i}/{len(video_dirs)}] {status} '{name}' — {ok} frames")
            except Exception as e:
                log.error(f"  [{i}/{len(video_dirs)}] ✗ '{os.path.basename(vdir)}': {e}")

    wrapper.stop()

    log.info("=== Done ===")
    log.info(f"  Total frames OK      : {total_ok}")
    log.info(f"  Total frames skipped : {total_skipped}")