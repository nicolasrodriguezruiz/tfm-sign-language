#!/bin/bash
# =============================================================================
# setup_openpose.sh
# Instala y compila OpenPose en Ubuntu 20.04
# 
# Usar:
#   chmod +x setup_openpose.sh
#   ./setup_openpose.sh
#
# Variables:
#   OPENPOSE_DIR  — Donde clonar OpenPose
#   CONDA_ENV     — Nombre del env a uar
# =============================================================================

set -e   # exit immediately on error

OPENPOSE_DIR="${HOME}/work/openpose"
CONDA_ENV="openpose"

echo "============================================="
echo " OpenPose Setup — Ubuntu 20.04"
echo "============================================="

# -----------------------------------------------------------------------------
# 1. System dependencies via apt
# -----------------------------------------------------------------------------
echo ""
echo ">>> [1/5] Installing apt dependencies..."
sudo apt-get update -q
sudo apt-get install -y \
    cmake \
    libboost-all-dev \
    libprotobuf-dev \
    protobuf-compiler \
    libgflags-dev \
    libgoogle-glog-dev \
    libhdf5-dev \
    libatlas-base-dev \
    libopencv-dev \
    libeigen3-dev

# -----------------------------------------------------------------------------
# 2. Conda environment
# -----------------------------------------------------------------------------
echo ""
echo ">>> [2/5] Creating conda environment '${CONDA_ENV}'..."

# Use mamba if available (much faster than conda)
if command -v mamba &> /dev/null; then
    CONDA_CMD="mamba"
else
    CONDA_CMD="conda"
    echo "    (mamba not found, using conda — consider: conda install mamba -c conda-forge)"
fi

$CONDA_CMD create -n "$CONDA_ENV" python=3.9 numpy=1.23.5 -y

# -----------------------------------------------------------------------------
# 3. Clone OpenPose
# -----------------------------------------------------------------------------
echo ""
echo ">>> [3/5] Cloning OpenPose into ${OPENPOSE_DIR}..."

if [ -d "$OPENPOSE_DIR" ]; then
    echo "    Directory already exists, skipping clone."
else
    git clone https://github.com/CMU-Perceptual-Computing-Lab/openpose.git "$OPENPOSE_DIR"
fi

cd "$OPENPOSE_DIR"
git submodule update --init --recursive

# -----------------------------------------------------------------------------
# 4. Build — conda must be DEACTIVATED during cmake/make to avoid
#    protobuf conflicts (OpenPose uses the system protobuf via apt)
# -----------------------------------------------------------------------------
echo ""
echo ">>> [4/5] Building OpenPose (conda deactivated during build)..."

# No funciona en el env de conda (segun documentacion)
conda deactivate 2>/dev/null || true
conda deactivate 2>/dev/null || true

mkdir -p "${OPENPOSE_DIR}/build"
cd "${OPENPOSE_DIR}/build"

cmake .. \
    -DBUILD_PYTHON=ON \
    -DCMAKE_BUILD_TYPE=Release

make -j"$(nproc)" 2>&1 | tee "${OPENPOSE_DIR}/build/make_output.log"

echo "    Build complete."

# -----------------------------------------------------------------------------
# 5. Install Python bindings into the conda environment
# -----------------------------------------------------------------------------
echo ""
echo ">>> [5/5] Installing Python bindings into conda env '${CONDA_ENV}'..."

# Activate the conda env
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate "$CONDA_ENV"

# Copy the .so to site-packages
SO_FILE=$(find "${OPENPOSE_DIR}/build/python/openpose" -name "pyopenpose*.so" | head -1)

if [ -z "$SO_FILE" ]; then
    echo "ERROR: pyopenpose .so not found. Check the build logs."
    exit 1
fi

SITE_PACKAGES=$(python -c "import site; print(site.getsitepackages()[0])")
cp "$SO_FILE" "$SITE_PACKAGES"
echo "    Copied ${SO_FILE} → ${SITE_PACKAGES}"

# Hay un coflicto libstdc++ (o lo habia en mi prueba anterior)
conda env config vars set \
    LD_PRELOAD="${CONDA_PREFIX}/lib/libstdc++.so.6" \
    -n "$CONDA_ENV"

# Reactivate so the env var takes effect
conda activate "$CONDA_ENV"

# Verify
python -c "import pyopenpose; print('    pyopenpose import OK')"

echo ""
echo "============================================="
echo " Done! Activate the environment with:"
echo "   conda activate ${CONDA_ENV}"
echo "============================================="
