"""
extract_keypoints_parallel.py
=============================
Launches N independent processes, each running its own OpenPose wrapper
on a separate subset of videos. All processes share the same GPU.

With 2 processes on A100 (~11GB each = ~22GB total, well within 40GB):
    ~2x speedup over single process

Usage:
    python extract_keypoints_parallel.py --splits train dev test --gpu_number 0 --num_workers 3
"""

import os
import sys
import json
import argparse
import logging
import queue
import threading
import multiprocessing
from datetime import datetime

import cv2

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_FRAMES_DIR   = "/home/user/work/data/PHOENIX-2014-T-release-v3/PHOENIX-2014-T/features/fullFrame-210x260px"
DEFAULT_OUTPUT_DIR   = "/home/user/work/data/openpose_output"
DEFAULT_OPENPOSE_DIR = "/home/user/work/openpose"
DEFAULT_SPLITS       = ["train", "dev", "test"]
DEFAULT_LOG_DIR      = "./"
DEFAULT_NUM_WORKERS  = 2


# ---------------------------------------------------------------------------
# Logger — each worker writes to its own log file
# ---------------------------------------------------------------------------

def setup_logger(log_dir: str, worker_id: int = -1) -> logging.Logger:
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix    = f"_worker{worker_id}" if worker_id >= 0 else ""
    log_path  = os.path.join(log_dir, f"extraction_{timestamp}{suffix}.log")

    name   = f"extractor{suffix}"
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    fmt = logging.Formatter("%(asctime)s | %(message)s", datefmt="%H:%M:%S")
    fh  = logging.FileHandler(log_path, encoding="utf-8")
    ch  = logging.StreamHandler()
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


# ---------------------------------------------------------------------------
# OpenPose init
# ---------------------------------------------------------------------------

def init_openpose(openpose_dir: str, gpu_number: int, logger):
    py_path = os.path.join(openpose_dir, "build", "python")
    if py_path not in sys.path:
        sys.path.insert(0, py_path)

    import pyopenpose as op

    params = {
        "model_folder":          os.path.join(openpose_dir, "models"),
        "model_pose":            "BODY_25",
        "hand":                  True,
        "face":                  False,
        "net_resolution": "256x256",      
      #  "hand_net_resolution": "128x128", 
        "render_pose": 0,
        "num_gpu":               1,
        "num_gpu_start":         gpu_number,
        "disable_multi_thread":  False,
    }
    
    wrapper = op.WrapperPython()
    wrapper.configure(params)
    wrapper.start()
    logger.info(f"OpenPose wrapper initialised (GPU:{gpu_number})")
    return wrapper, op


# ---------------------------------------------------------------------------
# Per-video pipeline: reader → inference → writer
# ---------------------------------------------------------------------------

def process_video(wrapper, op, video_dir: str, output_dir: str,
                  logger, read_ahead: int = 128) -> tuple:
    _SENTINEL  = None
    video_name = os.path.basename(video_dir)
    os.makedirs(output_dir, exist_ok=True)

    all_frames = sorted([
        f for f in os.listdir(video_dir)
        if f.lower().endswith(".png") or f.lower().endswith(".jpg")
    ])

    pending, already_done = [], 0
    for frame_file in all_frames:
        stem = os.path.splitext(frame_file)[0]
        if os.path.exists(os.path.join(output_dir, f"{stem}_keypoints.json")):
            already_done += 1
        else:
            pending.append(frame_file)

    if not pending:
        return video_name, already_done, 0

    read_queue  = queue.Queue(maxsize=read_ahead)
    write_queue = queue.Queue(maxsize=read_ahead)
    errors      = []

    def reader():
        for frame_file in pending:
            img = cv2.imread(os.path.join(video_dir, frame_file))
            read_queue.put((frame_file, img))
        read_queue.put(_SENTINEL)

    def writer():
        while True:
            item = write_queue.get()
            if item is _SENTINEL:
                break
            frame_file, keypoints = item
            stem        = os.path.splitext(frame_file)[0]
            output_path = os.path.join(output_dir, f"{stem}_keypoints.json")
            try:
                with open(output_path, "w") as f:
                    json.dump(keypoints, f)
            except Exception as e:
                errors.append(f"Write error {frame_file}: {e}")
            finally:
                write_queue.task_done()

    threading.Thread(target=reader, daemon=True).start()
    writer_thread = threading.Thread(target=writer, daemon=True)
    writer_thread.start()

    ok, skipped = already_done, 0
    while True:
        item = read_queue.get()
        if item is _SENTINEL:
            break
        frame_file, img = item
        if img is None:
            skipped += 1
            continue
        try:
            datum = op.Datum()
            datum.cvInputData = img
            wrapper.emplaceAndPop(op.VectorDatum([datum]))

            people = []
            if datum.poseKeypoints is not None and len(datum.poseKeypoints) > 0:
                pose  = datum.poseKeypoints[0].flatten().tolist()
                lhand = datum.handKeypoints[0][0].flatten().tolist() \
                        if datum.handKeypoints is not None else [0.0] * 63
                rhand = datum.handKeypoints[1][0].flatten().tolist() \
                        if datum.handKeypoints is not None else [0.0] * 63
                people.append({
                    "pose_keypoints_2d":       pose,
                    "hand_left_keypoints_2d":  lhand,
                    "hand_right_keypoints_2d": rhand,
                })
            write_queue.put((frame_file, {"people": people}))
            ok += 1
        except Exception as e:
            logger.warning(f"  [{video_name}] Inference error {frame_file}: {e}")
            skipped += 1

    write_queue.put(_SENTINEL)
    writer_thread.join()
    return video_name, ok, skipped


# ---------------------------------------------------------------------------
# Worker process — runs independently with its own OpenPose wrapper
# ---------------------------------------------------------------------------

def worker_fn(worker_id: int, video_dirs: list, output_dirs: list,
              openpose_dir: str, gpu_number: int, log_dir: str):
    """
    Runs in a separate process. Initialises its own OpenPose wrapper
    and processes the assigned subset of video directories.
    """
    logger = setup_logger(log_dir, worker_id)
    logger.info(f"=== Worker {worker_id} started — {len(video_dirs)} videos ===")

    try:
        wrapper, op = init_openpose(openpose_dir, gpu_number, logger)
    except Exception as e:
        logger.error(f"Worker {worker_id} failed to init OpenPose: {e}")
        return

    total_ok, total_skipped = 0, 0
    for i, (vdir, vout) in enumerate(zip(video_dirs, output_dirs), 1):
        try:
            name, ok, skipped = process_video(wrapper, op, vdir, vout, logger)
            total_ok      += ok
            total_skipped += skipped
            status = "✓" if skipped == 0 else f"⚠ {skipped} skipped"
            logger.info(f"  [{i}/{len(video_dirs)}] {status} '{name}' — {ok} frames")
        except Exception as e:
            logger.error(f"  [{i}/{len(video_dirs)}] ✗ '{os.path.basename(vdir)}': {e}")

    wrapper.stop()
    logger.info(f"=== Worker {worker_id} done — {total_ok} OK, {total_skipped} skipped ===")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="Parallel OpenPose extraction — N workers on same GPU."
    )
    parser.add_argument("--frames_dir",   default=DEFAULT_FRAMES_DIR)
    parser.add_argument("--output_dir",   default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--openpose_dir", default=DEFAULT_OPENPOSE_DIR)
    parser.add_argument("--splits",       nargs="+", default=DEFAULT_SPLITS)
    parser.add_argument("--gpu_number",   type=int, default=0,
                        help="GPU device id (0 = first GPU)")
    parser.add_argument("--num_workers",  type=int, default=DEFAULT_NUM_WORKERS,
                        help="Number of parallel OpenPose processes (default: 2)")
    parser.add_argument("--log_dir",      default=DEFAULT_LOG_DIR)
    return parser.parse_args()


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn", force=True)
    args = parse_args()

    # Main logger
    log = setup_logger(args.log_dir)
    log.info("=== PHOENIX-2014-T Parallel Keypoint Extraction ===")
    log.info(f"  frames_dir   : {args.frames_dir}")
    log.info(f"  output_dir   : {args.output_dir}")
    log.info(f"  splits       : {args.splits}")
    log.info(f"  gpu_number   : {args.gpu_number}")
    log.info(f"  num_workers  : {args.num_workers}")

    for split in args.splits:
        split_dir = os.path.join(args.frames_dir, split)
        split_out = os.path.join(args.output_dir, split)

        if not os.path.isdir(split_dir):
            log.warning(f"Split dir not found, skipping: {split_dir}")
            continue

        video_dirs = sorted([e.path for e in os.scandir(split_dir) if e.is_dir()])
        output_dirs = [os.path.join(split_out, os.path.basename(v)) for v in video_dirs]

        log.info(f"--- Split '{split}': {len(video_dirs)} videos → {args.num_workers} workers ---")

        # Divide videos evenly across workers
        chunks_v = [video_dirs[i::args.num_workers]  for i in range(args.num_workers)]
        chunks_o = [output_dirs[i::args.num_workers] for i in range(args.num_workers)]

        processes = []
        for wid in range(args.num_workers):
            p = multiprocessing.Process(
                target=worker_fn,
                args=(wid, chunks_v[wid], chunks_o[wid],
                      args.openpose_dir, args.gpu_number, args.log_dir),
                daemon=False,
            )
            p.start()
            log.info(f"  Launched worker {wid} — {len(chunks_v[wid])} videos (PID {p.pid})")
            
            processes.append(p)
            
        with open(os.path.join(args.log_dir,'kill_workers.sh'), 'w') as f:
            pids = " ".join(str(pr.pid) for pr in processes)
            f.write(f"kill {pids}\n")
                
        for p in processes:
            p.join()

        log.info(f"--- Split '{split}' complete ---")

    log.info("=== All splits done ===")